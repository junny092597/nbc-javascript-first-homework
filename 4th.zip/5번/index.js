// 여기에 1번 문제의 답을 작성하세요.
async function fetchData() {
    try {
      const response = await fetch('https://dummyjson.com/products');
      const data = await response.json();
      console.log(data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }
  
  fetchData();
// 여기에 2번 문제의 답을 작성하세요.
async function postData() {
    const url = 'https://dummyjson.com/products/add';
    const data = {
      title: 'BMW Pencil',
      /* other product data */
    };
  
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
  
      const result = await response.json();
      console.log(result);
    } catch (error) {
      console.error('Error posting data:', error);
    }
  }
  
  postData();